import 'package:flutter/material.dart';
import 'package:flutter_quiz_app/quiz.dart';

void main() {
  runApp(const Quiz());
}
