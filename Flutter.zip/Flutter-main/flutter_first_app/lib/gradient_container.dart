import 'package:first_app/dice_roller.dart';
import 'package:flutter/material.dart';

const startAlignment = Alignment.topLeft;
const endAlignment = Alignment.bottomRight;

class GradientContainer extends StatelessWidget {
  final Color startColor;
  final Color endColor;

  // final List<Color> colors;

  const GradientContainer(this.startColor, this.endColor, {super.key});
  // const GradientContainer({super.key, required this.colors});

  const GradientContainer.purple({super.key})
      : startColor = const Color.fromARGB(255, 164, 140, 208),
        endColor = const Color.fromARGB(255, 81, 45, 168);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [startColor, endColor],
          // colors: colors,
          begin: startAlignment,
          end: endAlignment,
        ),
      ),
      child: const Center(
        child: DiceRoller(),
      ),
    );
  }
}
