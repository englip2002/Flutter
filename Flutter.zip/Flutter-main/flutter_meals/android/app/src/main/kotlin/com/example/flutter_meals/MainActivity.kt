package com.example.flutter_meals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
