package com.example.flutter_favourite_places

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
